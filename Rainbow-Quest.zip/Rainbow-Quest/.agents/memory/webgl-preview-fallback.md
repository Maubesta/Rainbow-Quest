---
name: WebGL preview fallback
description: Replit screenshot browsers may not provide a WebGL context for React Three Fiber apps.
---

Check WebGL availability before mounting a React Three Fiber `Canvas`. In the screenshot browser, creating the Three renderer failed before the `Canvas` fallback rendered, and the app's outer error boundary replaced the whole screen. A client-side capability probe let the page show a DOM scene fallback and explain that 3D acceleration is needed.

**Why:** The preview capture environment did not expose a working WebGL context, even though the project itself compiled and its Vite workflow started normally.

**How to apply:** For future browser games that require WebGL, render a graceful fallback before mounting the renderer. A screenshot of the DOM fallback does not confirm that actual 3D gameplay works in a GPU-enabled browser.
