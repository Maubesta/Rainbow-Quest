import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { PerspectiveCamera, Text, useKeyboardControls, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import { Suspense, type CSSProperties, type PointerEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { BookOpen, GraduationCap, Pause, Play, RotateCcw, Sparkles } from 'lucide-react';

type GameStatus = 'menu' | 'playing' | 'paused' | 'question' | 'over' | 'won';
type Obstacle = { id: number; lane: number; born: number };
type HeartPickupData = { id: number; lane: number; born: number };
type MathQuestion = { prompt: string; answer: number; options: number[] };

function SceneFallback() {
  return <div className="scene-fallback" aria-hidden="true">
    <div className="fallback-sun" />
    <div className="fallback-school fallback-school-left" />
    <div className="fallback-school fallback-school-right" />
    <div className="fallback-track"><i /><i /></div>
    <img className="fallback-car" src={`${import.meta.env.BASE_URL}textures/car-obstacle.jpg`} alt="" />
    <div className="fallback-runner"><i /><b /></div>
  </div>;
}

function CarObstacle() {
  const texture = useTexture(`${import.meta.env.BASE_URL}textures/car-obstacle.jpg`);
  const carTexture = useMemo(() => {
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, [texture]);

  return <mesh position={[0, .76, 0]}>
    <planeGeometry args={[2.3, 1.47]} />
    <meshBasicMaterial map={carTexture} side={THREE.DoubleSide} toneMapped={false} />
  </mesh>;
}

const laneX = [-2.55, 0, 2.55];
const phases = [
  { label: 'Pátio da escola', start: 0 },
  { label: 'Corredor das contas', start: 420 },
  { label: 'Desafio do recreio', start: 1050 },
  { label: 'Grande volta', start: 1850 },
];
const characters = [
  { shirt: '#126d88', skin: '#a86442', hair: '#30241f' },
  { shirt: '#f5f1e6', skin: '#bf8b6d', hair: '#251b1d' },
  { shirt: '#f0bf25', skin: '#98634e', hair: '#38302d' },
  { shirt: '#f8f2e8', skin: '#d39a78', hair: '#302521' },
];
type ControlName = 'left' | 'right' | 'jump' | 'pause' | 'start';
type GameControls = Record<ControlName, boolean>;

function PlayerPortrait({ character }: { character: number }) {
  const texture = useTexture(`${import.meta.env.BASE_URL}characters/character-${character + 1}-round.png`);
  const portraitTexture = useMemo(() => {
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, [texture]);

  return <mesh position={[0, 2.02, .42]}>
    <planeGeometry args={[.72, .72]} />
    <meshBasicMaterial map={portraitTexture} transparent alphaTest={.04} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
  </mesh>;
}
function PassageBackground() {
  const texture = useTexture(`${import.meta.env.BASE_URL}textures/passage-background.webp`);
  const { scene, size } = useThree();

  useEffect(() => {
    const image = texture.image as HTMLImageElement;
    const imageAspect = image.width / image.height;
    const viewportAspect = size.width / Math.max(1, size.height);
    const visibleWidth = viewportAspect < imageAspect ? viewportAspect / imageAspect : 1;
    const visibleHeight = viewportAspect > imageAspect ? imageAspect / viewportAspect : 1;
    const previousBackground = scene.background;

    texture.colorSpace = THREE.SRGBColorSpace;
    texture.wrapS = THREE.ClampToEdgeWrapping;
    texture.wrapT = THREE.ClampToEdgeWrapping;
    texture.repeat.set(visibleWidth, visibleHeight);
    texture.offset.set((1 - visibleWidth) / 2, (1 - visibleHeight) / 2);
    texture.needsUpdate = true;
    scene.background = texture;

    return () => {
      scene.background = previousBackground;
      texture.repeat.set(1, 1);
      texture.offset.set(0, 0);
      texture.needsUpdate = true;
    };
  }, [scene, size.height, size.width, texture]);

  return null;
}

function ChaserPortrait() {
  const texture = useTexture(`${import.meta.env.BASE_URL}characters/albertao-round.png`);
  const portraitTexture = useMemo(() => {
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, [texture]);

  return <mesh position={[0, 2.02, .42]}>
    <planeGeometry args={[.72, .72]} />
    <meshBasicMaterial map={portraitTexture} transparent alphaTest={.04} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
  </mesh>;
}

function DonaPininaHeart() {
  const texture = useTexture(`${import.meta.env.BASE_URL}characters/dona-pinina-coracao.png`);
  const heartTexture = useMemo(() => {
    texture.colorSpace = THREE.SRGBColorSpace;
    return texture;
  }, [texture]);

  return <group>
    <mesh position={[0, 1.08, 0]}>
      <planeGeometry args={[1.35, 1.35]} />
      <meshBasicMaterial map={heartTexture} transparent alphaTest={.04} depthWrite={false} side={THREE.DoubleSide} toneMapped={false} />
    </mesh>
    <Text position={[0, 2.02, .03]} fontSize={.24} color="#fff8e5" outlineColor="#8f3d67" outlineWidth={.025} anchorX="center" anchorY="middle">
      Dona Pinina Coração
    </Text>
  </group>;
}

type MathOperation = 'addition' | 'subtraction' | 'division' | 'square-root';

function makeQuestion(phase: number): MathQuestion {
  const level = Math.max(0, Math.min(3, phase));
  const operations: MathOperation[] = level === 0
    ? ['addition', 'subtraction']
    : level === 1
      ? ['addition', 'subtraction', 'division']
      : ['addition', 'subtraction', 'division', 'square-root'];
  const operation = operations[Math.floor(Math.random() * operations.length)];
  let answer = 0;
  let prompt = '';

  if (operation === 'addition') {
    const range = 20 + level * 12;
    const a = 2 + Math.floor(Math.random() * range);
    const b = 2 + Math.floor(Math.random() * range);
    answer = a + b;
    prompt = `Quanto é ${a} + ${b}?`;
  } else if (operation === 'subtraction') {
    const a = 10 + Math.floor(Math.random() * (24 + level * 18));
    const b = 1 + Math.floor(Math.random() * Math.min(a - 1, 14 + level * 12));
    answer = a - b;
    prompt = `Quanto é ${a} − ${b}?`;
  } else if (operation === 'division') {
    const divisor = 2 + Math.floor(Math.random() * (level === 1 ? 5 : level === 2 ? 7 : 9));
    const quotient = 2 + Math.floor(Math.random() * (level === 1 ? 5 : level === 2 ? 8 : 10));
    answer = quotient;
    prompt = `Quanto é ${divisor * quotient} ÷ ${divisor}?`;
  } else {
    const root = 2 + Math.floor(Math.random() * (level === 2 ? 5 : 10));
    answer = root;
    prompt = `Quanto é √${root * root}?`;
  }

  const distractors = new Set<number>();
  while (distractors.size < 2) {
    const offset = (Math.floor(Math.random() * 9) + 1) * (Math.random() > .5 ? 1 : -1);
    if (answer + offset > 0 && answer + offset !== answer) distractors.add(answer + offset);
  }
  return { prompt, answer, options: [answer, ...distractors].sort(() => Math.random() - .5) };
}

function SchoolWorld({ running, lane, jumping, distance, lives, selectedCharacter, onDistance, onCollision, onHeartCollected, onReachGoal, onPhase }: {
  running: boolean; lane: number; jumping: boolean; distance: number;
  lives: number; selectedCharacter: number;
  onDistance: (n: number) => void; onCollision: () => void; onHeartCollected: () => void; onReachGoal: () => void; onPhase: (n: number) => void;
}) {
  const trackRef = useRef<THREE.Group>(null);
  const runnerRef = useRef<THREE.Group>(null);
  const runnerArms = useRef<THREE.Group[]>([]);
  const runnerLegs = useRef<THREE.Group[]>([]);
  const runnerDust = useRef<THREE.Mesh[]>([]);
  const chaserRef = useRef<THREE.Group>(null);
  const chaserArms = useRef<THREE.Group[]>([]);
  const chaserLegs = useRef<THREE.Group[]>([]);
  const nextSpawn = useRef(22);
  const meter = useRef(0);
  const lastPhase = useRef(0);
  const lastTick = useRef(0);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);
  const obstacleRefs = useRef<Map<number, THREE.Group>>(new Map());
  const [hearts, setHearts] = useState<HeartPickupData[]>([]);
  const heartRefs = useRef<Map<number, THREE.Group>>(new Map());
  const heartRef = useRef(hearts);
  heartRef.current = hearts;
  const heartHitIds = useRef(new Set<number>());
  const heartIdRef = useRef(0);
  const laneTarget = useRef(0);
  const hop = useRef(0);
  const hitIds = useRef(new Set<number>());
  const idRef = useRef(0);
  const runTime = useRef(0);
  const chaseTime = useRef(0);
  const obstacleRef = useRef(obstacles);
  obstacleRef.current = obstacles;
  laneTarget.current = lane;
  const avatar = characters[selectedCharacter] ?? characters[0];
  const { size } = useThree();
  const [, getControls] = useKeyboardControls<ControlName>();
  const previousKeys = useRef<GameControls>({ left: false, right: false, jump: false, pause: false, start: false });
  const speedForDistance = (d: number) => 12.5 + Math.min(10, d / 190) + (d >= 700 ? 1.4 : 0);
  const phaseForDistance = (d: number) => d >= 1850 ? 3 : d >= 1050 ? 2 : d >= 420 ? 1 : 0;

  useFrame((_, delta) => {
    const keys = getControls();
    const previous = previousKeys.current;
    if (keys.left && !previous.left) window.dispatchEvent(new CustomEvent('game:move', { detail: -1 }));
    if (keys.right && !previous.right) window.dispatchEvent(new CustomEvent('game:move', { detail: 1 }));
    if (keys.jump && !previous.jump) window.dispatchEvent(new CustomEvent('game:jump'));
    if (keys.pause && !previous.pause) window.dispatchEvent(new CustomEvent('game:pause'));
    if (keys.start && !previous.start) window.dispatchEvent(new CustomEvent('game:start'));
    previousKeys.current = keys;

    if (running) {
      const dt = Math.min(delta, .05);
      const speed = speedForDistance(meter.current);
      runTime.current += dt * (8 + Math.min(5, meter.current / 450));
      meter.current += speed * dt;
      if (meter.current >= 1000) {
        meter.current = 1000;
        onDistance(1000);
        onReachGoal();
        return;
      }
      if (meter.current - lastTick.current > .12) {
        lastTick.current = meter.current;
        onDistance(Math.floor(meter.current));
      }
      const phase = phaseForDistance(meter.current);
      if (phase !== lastPhase.current) { lastPhase.current = phase; onPhase(phase); }
      const interval = Math.max(10, 20 - phase * 2.1);
      if (meter.current >= nextSpawn.current) {
        const count = phase === 0 || Math.random() < .4 ? 1 : 2;
        const lanes = [0, 1, 2].sort(() => Math.random() - .5).slice(0, count);
        const batch = lanes.map(l => {
          const id = ++idRef.current;
          return { id, lane: l, born: meter.current + 43 };
        });
        setObstacles(old => [...old, ...batch]);
        if (lives < 2 && Math.random() < .05) {
          const safeLanes = [0, 1, 2].filter(availableLane => !lanes.includes(availableLane));
          if (safeLanes.length) {
            const id = ++heartIdRef.current;
            const heartLane = safeLanes[Math.floor(Math.random() * safeLanes.length)];
            setHearts(old => [...old, { id, lane: heartLane, born: meter.current + 43 }]);
          }
        }
        nextSpawn.current += interval + Math.random() * 5;
      }
      const remove: number[] = [];
      for (const item of obstacleRef.current) {
        const z = 2.4 - (item.born - meter.current) * .105;
        const ref = obstacleRefs.current.get(item.id);
        if (ref) ref.position.z = z;
        if (z > 1.1 && z < 3.3 && !hitIds.current.has(item.id)) {
          hitIds.current.add(item.id);
          if (item.lane === laneTarget.current && hop.current < .52) onCollision();
        }
        if (z > 8) remove.push(item.id);
      }
      if (remove.length) {
        remove.forEach(id => { obstacleRefs.current.delete(id); hitIds.current.delete(id); });
        setObstacles(old => old.filter(item => !remove.includes(item.id)));
      }
      const removeHearts: number[] = [];
      for (const item of heartRef.current) {
        const z = 2.4 - (item.born - meter.current) * .105;
        const ref = heartRefs.current.get(item.id);
        if (ref) ref.position.z = z;
        if (z > 1.1 && z < 3.3 && !heartHitIds.current.has(item.id)) {
          heartHitIds.current.add(item.id);
          if (item.lane === laneTarget.current) {
            onHeartCollected();
            removeHearts.push(item.id);
          }
        }
        if (z > 8) removeHearts.push(item.id);
      }
      if (removeHearts.length) {
        removeHearts.forEach(id => { heartRefs.current.delete(id); heartHitIds.current.delete(id); });
        setHearts(old => old.filter(item => !removeHearts.includes(item.id)));
      }
    }
    const targetX = laneX[laneTarget.current];
    if (runnerRef.current) {
      runnerRef.current.position.x += (targetX - runnerRef.current.position.x) * Math.min(1, delta * 12);
      if (running) hop.current = jumping ? Math.min(.95, hop.current + delta * 4) : Math.max(0, hop.current - delta * 4.2);
      const runBounce = running ? Math.abs(Math.sin(runTime.current * 2)) * .055 : 0;
      const stride = running ? Math.sin(runTime.current) * .62 : 0;
      runnerRef.current.position.y = .02 + hop.current * 1.45 + runBounce;
      runnerRef.current.rotation.x = running ? -.065 : 0;
      runnerRef.current.rotation.z = (targetX - runnerRef.current.position.x) * .035 + (running ? Math.sin(runTime.current * .5) * .018 : 0);
      runnerArms.current.forEach((arm, index) => { arm.rotation.x = stride * (index === 0 ? 1 : -1); });
      runnerLegs.current.forEach((leg, index) => { leg.rotation.x = stride * (index === 0 ? -1 : 1); });
      runnerDust.current.forEach((puff, index) => {
        const pulse = running ? (1 + Math.sin(runTime.current * 2 + index * Math.PI)) / 2 : 0;
        puff.scale.set(.65 + pulse * .8, .45 + pulse * .25, .65 + pulse * .5);
        const material = puff.material as THREE.MeshBasicMaterial;
        material.opacity = running ? .06 + pulse * .16 : 0;
      });
    }
    if (chaserRef.current && running) {
      chaseTime.current += delta;
      const followX = runnerRef.current?.position.x ?? targetX;
      chaserRef.current.position.x += (followX - chaserRef.current.position.x) * Math.min(1, delta * 1.8);
      chaserRef.current.position.y = .02 + Math.abs(Math.sin(chaseTime.current * 20)) * .04;
      chaserRef.current.rotation.x = -.065;
      chaserRef.current.rotation.z = (followX - chaserRef.current.position.x) * .025 + Math.sin(chaseTime.current * 5) * .012;
      const stride = Math.sin(chaseTime.current * 10) * .42;
      chaserArms.current.forEach((arm, index) => { arm.rotation.x = stride * (index === 0 ? 1 : -1); });
      chaserLegs.current.forEach((leg, index) => { leg.rotation.x = stride * (index === 0 ? -1 : 1); });
    }
    if (trackRef.current && running) trackRef.current.position.z = (meter.current * .72) % 7;
  });

  useEffect(() => {
    if (distance === 0) {
      meter.current = 0; nextSpawn.current = 22; lastPhase.current = 0; lastTick.current = 0;
      runTime.current = 0; chaseTime.current = 0;
      hitIds.current.clear(); obstacleRefs.current.clear(); setObstacles([]);
      heartHitIds.current.clear(); heartRefs.current.clear(); setHearts([]);
      heartIdRef.current = 0;
      if (runnerRef.current) { runnerRef.current.position.set(0, .02, 2.4); runnerRef.current.rotation.set(0, 0, 0); }
    }
  }, [distance === 0]);

  const buildings = useMemo(() => Array.from({ length: 9 }, (_, i) => ({
    z: -i * 16 - 8, side: i % 2 ? 1 : -1, color: ['#f5cf68', '#79cbd0', '#f39b80', '#a4d394', '#82b5df'][i % 5],
  })), []);
  return <>
    <fog attach="fog" args={['#a8e0e8', 34, 105]} />
    <PerspectiveCamera
      makeDefault
      position={[0, size.width < 640 ? 6.7 : 6.4, size.width < 640 ? 14 : 13.2]}
      rotation={[-.49, 0, 0]}
      fov={size.width < 640 ? 57 : 55}
    />
    <hemisphereLight args={['#e9ffff', '#9d8456', 2.1]} />
    <directionalLight position={[-8, 12, 7]} intensity={2.3} castShadow shadow-mapSize={[1024, 1024]} />
    <Suspense fallback={null}><PassageBackground /></Suspense>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.38, -47]} receiveShadow>
      <planeGeometry args={[180, 180]} /><meshStandardMaterial color="#83c878" />
    </mesh>
    <mesh position={[0, -.2, -60]} receiveShadow>
      <boxGeometry args={[8.8, .25, 155]} /><meshStandardMaterial color="#e8c77d" />
    </mesh>
    <group ref={trackRef}>
      {Array.from({ length: 20 }, (_, i) => <group key={i} position={[0, -.055, -i * 7]}>
        <mesh position={[-1.4, 0, 0]}><boxGeometry args={[.055, .025, 3]} /><meshStandardMaterial color="#fff1cf" /></mesh>
        <mesh position={[1.4, 0, 0]}><boxGeometry args={[.055, .025, 3]} /><meshStandardMaterial color="#fff1cf" /></mesh>
      </group>)}
    </group>
    {buildings.map((building, i) => <group key={`school-${i}`} position={[building.side * 9.2, 0, building.z]}>
      <mesh position={[0, 2, 0]} castShadow><boxGeometry args={[7.2, 4.4, 5]} /><meshStandardMaterial color={building.color} /></mesh>
      <mesh position={[0, 4.25, 0]}><boxGeometry args={[7.5, .35, 5.25]} /><meshStandardMaterial color="#df6b57" /></mesh>
      {[-2.1, 0, 2.1].map((x, n) => <mesh key={n} position={[x, 2.45, 2.53]}><boxGeometry args={[1.05, 1.2, .08]} /><meshStandardMaterial color="#8ed8e4" /></mesh>)}
      <mesh position={[0, .05, 2.6]}><boxGeometry args={[7.3, .16, .25]} /><meshStandardMaterial color="#fff4d6" /></mesh>
    </group>)}
    {[-1, 1].map((side, i) => <group key={`palm-${i}`} position={[side * 6.7, 0, -13 - i * 26]}>
      <mesh position={[0, 1.5, 0]}><cylinderGeometry args={[.17, .27, 3, 8]} /><meshStandardMaterial color="#986843" /></mesh>
      {[0, 1, 2, 3, 4].map(n => <mesh key={n} position={[Math.cos(n * 1.25) * .75, 3, Math.sin(n * 1.25) * .55]} rotation={[0, n * 1.25, Math.sin(n * 1.25) * .3]}><boxGeometry args={[1.8, .09, .28]} /><meshStandardMaterial color="#338d62" /></mesh>)}
    </group>)}
    <group ref={runnerRef} position={[0, .02, 2.4]} scale={1.14}>
      <mesh position={[0, 1.3, 0]} castShadow><boxGeometry args={[.8, .9, .45]} /><meshStandardMaterial color={avatar.shirt} /></mesh>
      <mesh position={[0, 2.02, 0]} castShadow><sphereGeometry args={[.4, 16, 12]} /><meshStandardMaterial color={avatar.skin} /></mesh>
      <mesh position={[0, 2.26, -.02]} scale={[1, .42, 1]} castShadow><sphereGeometry args={[.4, 12, 8]} /><meshStandardMaterial color={avatar.hair} /></mesh>
      <PlayerPortrait character={selectedCharacter} />
      {[-.15, .15].map(x => <mesh key={x} position={[x, 2.04, .34]}><sphereGeometry args={[.055, 8, 8]} /><meshStandardMaterial color="#fffaf0" /></mesh>)}
      <mesh position={[0, 1.36, .235]}><boxGeometry args={[.56, .15, .035]} /><meshStandardMaterial color="#ffe16c" emissive="#6b4a00" emissiveIntensity={.18} /></mesh>
      {[-.23, .23].map((x, index) => <group
        key={`runner-leg-${x}`}
        ref={node => { if (node) runnerLegs.current[index] = node; }}
        position={[x, .83, 0]}
      >
        <mesh position={[0, -.3, 0]} castShadow><boxGeometry args={[.24, .62, .28]} /><meshStandardMaterial color="#193c5b" /></mesh>
      </group>)}
      {[-.52, .52].map((x, index) => <group
        key={`runner-arm-${x}`}
        ref={node => { if (node) runnerArms.current[index] = node; }}
        position={[x, 1.62, 0]}
      >
        <mesh position={[0, -.3, 0]} castShadow><boxGeometry args={[.2, .64, .22]} /><meshStandardMaterial color={avatar.skin} /></mesh>
      </group>)}
      {[-1, 1].map((side, index) => <mesh
        key={`runner-dust-${side}`}
        ref={node => { if (node) runnerDust.current[index] = node; }}
        position={[side * .28, .08, .4]}
      >
        <sphereGeometry args={[.18, 10, 8]} />
        <meshBasicMaterial color="#fff1cf" transparent opacity={0} depthWrite={false} />
      </mesh>)}
    </group>
    <group ref={chaserRef} position={[0, .02, 4.45]} scale={.68}>
      <mesh position={[0, 1.3, 0]} castShadow><boxGeometry args={[.82, .92, .46]} /><meshStandardMaterial color="#e86e58" /></mesh>
      <mesh position={[0, 2.02, 0]} castShadow><sphereGeometry args={[.4, 16, 12]} /><meshStandardMaterial color="#bc805b" /></mesh>
      <mesh position={[0, 2.27, -.02]} scale={[1, .4, 1]} castShadow><sphereGeometry args={[.4, 12, 8]} /><meshStandardMaterial color="#51352b" /></mesh>
      <ChaserPortrait />
      {[-.15, .15].map(x => <mesh key={x} position={[x, 2.04, .34]}><sphereGeometry args={[.055, 8, 8]} /><meshStandardMaterial color="#fffaf0" /></mesh>)}
      <Text position={[0, 3.2, .02]} fontSize={.58} color="#ffe16c" outlineColor="#173450" outlineWidth={.045} anchorX="center" anchorY="middle">
        Albertão
      </Text>
      {[-1, 1].map((side, index) => <group
        key={`chaser-arm-${side}`}
        ref={node => { if (node) chaserArms.current[index] = node; }}
        position={[side * .53, 1.63, 0]}
      >
        <mesh position={[0, -.3, 0]} castShadow><boxGeometry args={[.2, .62, .22]} /><meshStandardMaterial color="#bc805b" /></mesh>
        {side === 1 && <group position={[0, -.56, .12]} rotation={[0, 0, -.4]}>
          <mesh position={[0, .13, 0]} castShadow><cylinderGeometry args={[.034, .04, .26, 10]} /><meshStandardMaterial color="#43352c" /></mesh>
          <mesh position={[0, .57, 0]} castShadow><cylinderGeometry args={[.083, .037, .68, 10]} /><meshStandardMaterial color="#b77a42" roughness={.72} /></mesh>
          <mesh position={[0, .93, 0]} castShadow><sphereGeometry args={[.082, 10, 8]} /><meshStandardMaterial color="#c18a4f" roughness={.7} /></mesh>
        </group>}
      </group>)}
      {[-1, 1].map((side, index) => <group
        key={`chaser-leg-${side}`}
        ref={node => { if (node) chaserLegs.current[index] = node; }}
        position={[side * .23, .8, 0]}
      >
        <mesh position={[0, -.3, 0]} castShadow><boxGeometry args={[.24, .62, .28]} /><meshStandardMaterial color="#274f72" /></mesh>
      </group>)}
    </group>
    <group position={[0, 0, 0]}>
      {obstacles.map(item => <group key={item.id} ref={node => { if (node) obstacleRefs.current.set(item.id, node); else obstacleRefs.current.delete(item.id); }} position={[laneX[item.lane], 0, 0]}>
        <Suspense fallback={<mesh position={[0, .76, 0]}><boxGeometry args={[2.3, 1.47, .08]} /><meshStandardMaterial color="#718a91" /></mesh>}>
          <CarObstacle />
        </Suspense>
      </group>)}
      {hearts.map(item => <group key={`heart-${item.id}`} ref={node => { if (node) heartRefs.current.set(item.id, node); else heartRefs.current.delete(item.id); }} position={[laneX[item.lane], 0, 0]}>
        <Suspense fallback={null}><DonaPininaHeart /></Suspense>
      </group>)}
    </group>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.04, -84]}><planeGeometry args={[13, 12]} /><meshStandardMaterial color="#49b6bc" /></mesh>
    <mesh position={[-6.5, .05, -84]}><boxGeometry args={[.08, .04, 12]} /><meshStandardMaterial color="#fff2d4" /></mesh>
  </>;
}

export default function ParaibaRun() {
  const [webglAvailable, setWebglAvailable] = useState(false);
  const [status, setStatus] = useState<GameStatus>('menu');
  const [lane, setLane] = useState(1);
  const [distance, setDistance] = useState(0);
  const [lives, setLives] = useState(2);
  const [rightAnswers, setRightAnswers] = useState(0);
  const [question, setQuestion] = useState<MathQuestion | null>(null);
  const [questionTime, setQuestionTime] = useState(12);
  const [phase, setPhase] = useState(0);
  const [phaseNotice, setPhaseNotice] = useState<number | null>(null);
  const [toast, setToast] = useState('');
  const [selectedCharacter, setSelectedCharacter] = useState(0);
  const [meteorActive, setMeteorActive] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const [best, setBest] = useState(() => Number(localStorage.getItem('pmr_best') || 0));
  const [jumping, setJumping] = useState(false);
  const statusRef = useRef(status);
  const lifeRef = useRef(lives);
  const distanceRef = useRef(distance);
  const resumeRef = useRef<GameStatus>('playing');
  const invulnerable = useRef(0);
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  const musicRef = useRef<HTMLAudioElement | null>(null);
  const meteorAudioRef = useRef<AudioContext | null>(null);
  const nextQuestionAt = useRef(130);
  const speedUpAnnounced = useRef(false);
  statusRef.current = status;
  lifeRef.current = lives;
  distanceRef.current = distance;
  const score = distance + rightAnswers * 100;
  const phaseIndex = Math.max(0, Math.min(phases.length - 1, phase));

  useEffect(() => {
    const probe = document.createElement('canvas');
    const context = probe.getContext('webgl2') || probe.getContext('webgl');
    setWebglAvailable(Boolean(context));
    context?.getExtension('WEBGL_lose_context')?.loseContext();
  }, []);

  const loseLife = useCallback(() => {
    if (statusRef.current !== 'playing' || invulnerable.current > 0) return;
    invulnerable.current = 1.1;
    const next = Math.max(0, lifeRef.current - 1);
    lifeRef.current = next;
    setLives(next);
    if (next <= 0) {
      statusRef.current = 'over';
      setStatus('over');
    }
    setToast('Quase! Vamos seguir com atenção.');
  }, []);

  const collectHeart = useCallback(() => {
    if (statusRef.current !== 'playing' || lifeRef.current >= 2) return;
    const next = Math.min(2, lifeRef.current + 1);
    lifeRef.current = next;
    setLives(next);
    setToast('Dona Pinina Coração! +1 vida');
  }, []);

  const reachGoal = useCallback(() => {
    if (statusRef.current !== 'playing') return;
    distanceRef.current = 1000;
    setDistance(1000);
    statusRef.current = 'won';
    setStatus('won');
    musicRef.current?.pause();
  }, []);

  const updateDistance = useCallback((nextDistance: number) => {
    const boundedDistance = Math.min(1000, nextDistance);
    distanceRef.current = boundedDistance;
    setDistance(boundedDistance);
  }, []);

  const startGame = useCallback(() => {
    const music = musicRef.current;
    if (music) {
      music.currentTime = 0;
      void music.play().catch(() => setToast('Não foi possível reproduzir a música neste navegador.'));
    }
    if (typeof window.AudioContext !== 'undefined') {
      meteorAudioRef.current ??= new window.AudioContext();
      if (meteorAudioRef.current.state === 'suspended') void meteorAudioRef.current.resume().catch(() => undefined);
    }
    statusRef.current = 'playing';
    setLane(1); setDistance(0); distanceRef.current = 0; setLives(2); lifeRef.current = 2;
    setRightAnswers(0); setPhase(0); setQuestion(null); setPhaseNotice(null); setJumping(false); nextQuestionAt.current = 130;
    speedUpAnnounced.current = false;
    invulnerable.current = 0; setToast(''); setMeteorActive(false); setShowGameOver(false); setStatus('playing');
  }, []);

  const moveLane = useCallback((delta: number) => {
    if (statusRef.current !== 'playing') return;
    setLane(old => Math.max(0, Math.min(2, old + delta)));
  }, []);
  const jump = useCallback(() => {
    if (statusRef.current === 'playing') {
      setJumping(true);
      window.setTimeout(() => setJumping(false), 440);
    }
  }, []);
  const togglePause = useCallback(() => {
    if (statusRef.current === 'playing' || statusRef.current === 'question') {
      resumeRef.current = statusRef.current;
      statusRef.current = 'paused';
      setStatus('paused');
    } else if (statusRef.current === 'paused') {
      statusRef.current = resumeRef.current;
      setStatus(resumeRef.current);
    }
  }, []);

  const playMeteorImpact = useCallback(() => {
    const context = meteorAudioRef.current;
    if (!context || context.state === 'closed') return;

    const now = context.currentTime;
    const master = context.createGain();
    master.gain.setValueAtTime(.58, now);
    master.gain.setValueAtTime(.58, now + 2.2);
    master.gain.exponentialRampToValueAtTime(.0001, now + 2.5);
    master.connect(context.destination);

    const makeBoomTone = (type: OscillatorType, from: number, to: number, volume: number, duration: number) => {
      const oscillator = context.createOscillator();
      const envelope = context.createGain();
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(from, now);
      oscillator.frequency.exponentialRampToValueAtTime(to, now + duration);
      envelope.gain.setValueAtTime(volume, now);
      envelope.gain.exponentialRampToValueAtTime(.001, now + duration);
      oscillator.connect(envelope);
      envelope.connect(master);
      oscillator.start(now);
      oscillator.stop(now + duration);
    };

    makeBoomTone('triangle', 82, 28, .7, 2.1);
    makeBoomTone('sine', 48, 23, .42, 2.35);

    const noiseLength = Math.floor(context.sampleRate * .9);
    const noiseBuffer = context.createBuffer(1, noiseLength, context.sampleRate);
    const noiseData = noiseBuffer.getChannelData(0);
    for (let i = 0; i < noiseData.length; i++) noiseData[i] = Math.random() * 2 - 1;
    const noise = context.createBufferSource();
    const lowPass = context.createBiquadFilter();
    const noiseEnvelope = context.createGain();
    noise.buffer = noiseBuffer;
    lowPass.type = 'lowpass';
    lowPass.frequency.setValueAtTime(640, now);
    noiseEnvelope.gain.setValueAtTime(.18, now);
    noiseEnvelope.gain.exponentialRampToValueAtTime(.001, now + .88);
    noise.connect(lowPass);
    lowPass.connect(noiseEnvelope);
    noiseEnvelope.connect(master);
    noise.start(now);
    window.setTimeout(() => master.disconnect(), 2600);
  }, []);

  useEffect(() => {
    const actions = [
      ['game:move', (event: Event) => moveLane((event as CustomEvent<number>).detail)],
      ['game:jump', jump],
      ['game:pause', togglePause],
      ['game:start', () => {
        if (statusRef.current === 'menu' || statusRef.current === 'over') startGame();
      }],
    ] as const;
    const preventScroll = (event: KeyboardEvent) => {
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', ' '].includes(event.key)) event.preventDefault();
    };
    const startFromKeyboard = (event: KeyboardEvent) => {
      if (event.key !== 'Enter' || (statusRef.current !== 'menu' && statusRef.current !== 'over')) return;
      if (event.target instanceof HTMLElement && event.target.closest('button')) return;
      startGame();
    };
    for (const [name, listener] of actions) window.addEventListener(name, listener);
    window.addEventListener('keydown', preventScroll);
    window.addEventListener('keydown', startFromKeyboard);
    return () => {
      for (const [name, listener] of actions) window.removeEventListener(name, listener);
      window.removeEventListener('keydown', preventScroll);
      window.removeEventListener('keydown', startFromKeyboard);
    };
  }, [jump, moveLane, startGame, togglePause]);

  useEffect(() => () => {
    void meteorAudioRef.current?.close();
  }, []);

  useEffect(() => {
    if (status !== 'playing') return;
    const timer = window.setInterval(() => {
      if (invulnerable.current > 0) invulnerable.current = Math.max(0, invulnerable.current - .1);
      if (distanceRef.current >= nextQuestionAt.current) {
        nextQuestionAt.current = distanceRef.current + Math.max(250, 350 - phaseIndex * 24);
        setQuestion(makeQuestion(phaseIndex));
        setQuestionTime(12);
        setStatus('question');
      }
    }, 100);
    return () => window.clearInterval(timer);
  }, [status, phaseIndex]);

  useEffect(() => {
    if (status !== 'playing' || distance < 700 || speedUpAnnounced.current) return;
    speedUpAnnounced.current = true;
    setToast('700 m! A corrida acelerou um pouco!');
  }, [distance, status]);

  useEffect(() => {
    if (status !== 'question') return;
    const timer = window.setInterval(() => setQuestionTime(value => {
      if (value <= .1) {
        window.clearInterval(timer);
        setQuestion(null);
        setToast('O tempo passou. Na próxima você consegue!');
        const next = Math.max(0, lifeRef.current - 1);
        lifeRef.current = next;
        setLives(next);
        const nextStatus = next > 0 ? 'playing' : 'over';
        statusRef.current = nextStatus;
        setStatus(nextStatus);
        return 0;
      }
      return value - .1;
    }), 100);
    return () => window.clearInterval(timer);
  }, [status]);

  useEffect(() => {
    if (status === 'over' || status === 'won') {
      const final = Math.floor(distanceRef.current + rightAnswers * 100);
      if (final > best) { localStorage.setItem('pmr_best', String(final)); setBest(final); }
    }
  }, [status, rightAnswers, best]);

  useEffect(() => {
    if (status === 'won') musicRef.current?.pause();
  }, [status]);

  useEffect(() => {
    if (status !== 'over') return;
    setMeteorActive(true);
    setShowGameOver(false);
    playMeteorImpact();
    const timer = window.setTimeout(() => {
      setMeteorActive(false);
      setShowGameOver(true);
    }, 2700);
    return () => window.clearTimeout(timer);
  }, [status, playMeteorImpact]);

  useEffect(() => {
    if (phase === 0 || status !== 'playing') return;
    setPhaseNotice(phase);
    const timer = window.setTimeout(() => setPhaseNotice(null), 2200);
    return () => window.clearTimeout(timer);
  }, [phase, status]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 1550);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const answerQuestion = (answer: number) => {
    if (status !== 'question' || !question) return;
    setQuestion(null);
    if (answer === question.answer) {
      setRightAnswers(old => old + 1);
      setToast('Muito bem! +100 pontos');
    } else {
      setToast('Essa passou. Tente a próxima!');
      const next = Math.max(0, lifeRef.current - 1);
      lifeRef.current = next;
      setLives(next);
      if (next <= 0) {
        statusRef.current = 'over';
        setStatus('over');
      }
    }
    if (lifeRef.current > 0) {
      statusRef.current = 'playing';
      setStatus('playing');
    }
  };

  const onPointerDown = (event: PointerEvent<HTMLDivElement>) => {
    if (event.pointerType === 'touch') touchStart.current = { x: event.clientX, y: event.clientY };
  };
  const onPointerUp = (event: PointerEvent<HTMLDivElement>) => {
    if (!touchStart.current) return;
    const dx = event.clientX - touchStart.current.x, dy = event.clientY - touchStart.current.y;
    touchStart.current = null;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 30) return;
    if (Math.abs(dx) > Math.abs(dy)) moveLane(dx > 0 ? 1 : -1);
    else if (dy < 0) jump();
  };

  return <main className={`game-shell ${meteorActive ? 'meteor-hit' : ''}`} onPointerDown={onPointerDown} onPointerUp={onPointerUp}>
    {webglAvailable ? <Canvas
      className="game-canvas"
      shadows
      dpr={[1, 1.65]}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={({ gl }) => { gl.outputColorSpace = THREE.SRGBColorSpace; }}
      fallback={<SceneFallback />}
    >
      <SchoolWorld
        running={status === 'playing'}
        lane={lane}
        jumping={jumping}
        distance={distance}
        lives={lives}
        selectedCharacter={selectedCharacter}
        onDistance={updateDistance}
        onCollision={loseLife}
        onHeartCollected={collectHeart}
        onReachGoal={reachGoal}
        onPhase={setPhase}
      />
    </Canvas> : <SceneFallback />}
    <div className="sky-wash" />
    {(status === 'playing' || status === 'question' || status === 'paused') && <div className="game-hud">
      <div className="brand-chip">FUJA DO ALBERTÃO</div>
      <div className="stats-row">
        <div className="stat-chip"><span className="stat-label">Fase</span><span className="stat-value">{phaseIndex + 1}</span></div>
        <div className="stat-chip"><span className="stat-label">Distância</span><span className="stat-value">{distance} m</span></div>
        <div className="stat-chip"><span className="stat-label">Pontos</span><span className="stat-value">{score}</span></div>
        <div className="stat-chip"><span className="stat-label">Vidas</span><span className="lives">{[0, 1].map(i => <i key={i} className={`life-dot ${i >= lives ? 'lost' : ''}`} />)}</span></div>
      </div>
      <button className="pause-button" data-testid="button-pause" onClick={togglePause} aria-label="Pausar jogo"><Pause size={17} /> <span className="sr-only">Pausar</span></button>
    </div>}
    {(status === 'playing' || status === 'question' || status === 'paused') && <div className="mission-banner">Missão: chegue à distância 1000 e zere!</div>}
    {status === 'playing' && <div className="lane-hint">← → trocar de pista <span aria-hidden> · </span> ↑ ou espaço pular <span aria-hidden> · </span> Esc pausar</div>}
    {(status === 'playing' || status === 'question') && <div className="touch-controls">
      <button className="touch-button" data-testid="button-lane-left" onClick={() => moveLane(-1)} aria-label="Pista à esquerda">‹</button>
      <div className="touch-group"><button className="touch-button" data-testid="button-jump" onClick={jump} aria-label="Pular">↑</button><button className="touch-button" data-testid="button-lane-right" onClick={() => moveLane(1)} aria-label="Pista à direita">›</button></div>
    </div>}
    {status === 'menu' && <div className="overlay"><section className="panel">
      <div className="panel-mark"><GraduationCap /></div>
      <p className="panel-kicker">Uma aventura de aprender</p>
       <h1 className="game-title game-title-home">Fuja do Albertão<span>(Jogo de Matemática)</span></h1>
       <p className="panel-copy">O Albertão está no seu encalço! Desvie dos carros na pista e mostre que sua cabeça é rápida.</p>
       <p className="character-picker-label">Escolha seu personagem</p>
       <div className="character-picker" role="group" aria-label="Escolha seu personagem">
         {characters.map((_, index) => <button
           key={index}
           type="button"
           className={`character-option ${selectedCharacter === index ? 'selected' : ''}`}
           aria-label={`Selecionar personagem ${index + 1}`}
           aria-pressed={selectedCharacter === index}
           onClick={() => setSelectedCharacter(index)}
         >
           <img src={`${import.meta.env.BASE_URL}characters/character-${index + 1}.jpg`} alt="" />
           <span>Personagem {index + 1}</span>
         </button>)}
       </div>
      <div className="instruction-grid">
        <div className="instruction"><span className="keycap">← →</span> ou A / D para mudar de pista</div>
        <div className="instruction"><span className="keycap">↑ espaço</span> para pular</div>
        <div className="instruction"><span className="keycap">Esc</span> para fazer uma pausa</div>
        <div className="instruction"><span className="keycap">Celular</span> deslize ou use os botões</div>
      </div>
       {!webglAvailable && <p className="webgl-note" role="status">Ative a aceleração gráfica do navegador para jogar em 3D.</p>}
       <button className="primary-button" data-testid="button-play" onClick={startGame} disabled={!webglAvailable}><Play size={19} fill="currentColor" /> Vamos correr!</button>
      <p className="record-note">Seu recorde: {best} pontos</p>
    </section></div>}
    {status === 'question' && question && <section className="math-card" aria-label="Pergunta de matemática">
      <div className="math-kicker"><BookOpen size={14} /> Desafio relâmpago</div>
      <h2 className="math-prompt">{question.prompt}</h2>
      <div className="answer-grid">{question.options.map((option, i) => <button key={option} className="answer-button" data-testid={`button-answer-${i}`} onClick={() => answerQuestion(option)}>{option}</button>)}</div>
      <div className="timer-track"><div className="timer-fill" style={{ width: `${Math.max(0, questionTime / 12 * 100)}%`, background: questionTime < 3 ? '#e56e72' : undefined }} /></div>
      <p className="record-note">Responda com calma, mas antes do tempo acabar.</p>
    </section>}
    {status === 'paused' && <div className="overlay"><section className="panel">
      <div className="panel-mark"><Pause /></div><p className="panel-kicker">Pausa para respirar</p>
      <h2 className="game-title">DESCANSO<span>A corrida espera por você</span></h2>
      <p className="panel-copy">A pista continua no mesmo lugar. Quando estiver pronto, é só voltar!</p>
      <button className="primary-button" data-testid="button-resume" onClick={togglePause}><Play size={19} fill="currentColor" /> Continuar</button>
      <button className="text-button" data-testid="button-restart-paused" onClick={startGame}>Começar de novo</button>
    </section></div>}
    {meteorActive && <div className="meteor-overlay" role="status" aria-label="Alberto Meteoro está caindo">
      <div className="meteor-trail" />
      <div className="meteor-rock" />
      <div className="meteor-name">Alberto Meteoro</div>
      <div className="meteor-blast">
        <div className="meteor-flash" />
        <div className="meteor-shockwave" />
        <div className="meteor-crater" />
        <svg className="impact-cracks" viewBox="0 0 700 700" aria-hidden="true">
          <path d="M350 350 310 285 325 236 278 192 293 134" />
          <path d="M350 350 405 294 391 246 438 210 427 155" />
          <path d="M350 350 294 375 250 349 202 382 151 366" />
          <path d="M350 350 408 381 456 357 500 397 556 380" />
          <path d="M350 350 334 414 359 459 340 511 365 563" />
          <path d="M350 350 300 320 260 279 221 267" />
          <path d="M350 350 390 330 425 289 472 272" />
        </svg>
        <div className="meteor-debris">{Array.from({ length: 10 }, (_, index) => <i key={index} />)}</div>
      </div>
    </div>}
    {status === 'over' && showGameOver && <div className="overlay"><section className="panel">
      <div className="panel-mark"><Sparkles /></div><p className="panel-kicker">Toda corrida ensina algo</p>
      <h2 className="game-title">FIM DE JOGO<span>Você foi muito longe!</span></h2>
      <p className="panel-copy">Distância: <strong>{distance} m</strong><br />Pontos: <strong>{score}</strong> · Contas certas: <strong>{rightAnswers}</strong></p>
      <button className="primary-button" data-testid="button-play-again" onClick={startGame}><RotateCcw size={19} /> Correr de novo</button>
      <p className="record-note">Recorde da casa: {best} pontos</p>
    </section></div>}
    {status === 'won' && <div className="win-overlay" role="dialog" aria-modal="true" aria-labelledby="win-title">
      <div className="fireworks" aria-hidden="true">
        {Array.from({ length: 4 }, (_, burst) => <div className={`firework firework-${burst + 1}`} key={burst}>
          {Array.from({ length: 12 }, (_, spark) => <i key={spark} style={{ '--spark-angle': `${spark * 30}deg` } as CSSProperties} />)}
        </div>)}
      </div>
      <section className="panel win-panel">
        <div className="panel-mark"><Sparkles /></div>
        <p className="panel-kicker">Missão cumprida · 1000 metros</p>
        <h2 className="game-title" id="win-title">VOCÊ ZEROU!<span>Agradecimentos</span></h2>
        <div className="developer-credit">
          <span>Desenvolvedor e mestre do jogo</span>
          <strong>Henrique Rodrigues</strong>
        </div>
        <p className="participants-label">Participantes do jogo</p>
        <ul className="participants-list">
          <li>Rayson Bezerro</li>
          <li>Wiliam Bonner</li>
          <li>João Vitinho</li>
          <li>Lázaro Barbosa</li>
          <li>Darlan Mitchell</li>
          <li>João King Sebastian</li>
        </ul>
        <p className="panel-copy">Distância: <strong>1000 m</strong> · Pontos: <strong>{score}</strong></p>
        <button className="primary-button" data-testid="button-play-again-won" onClick={startGame}><RotateCcw size={19} /> Correr de novo</button>
      </section>
    </div>}
    {phaseNotice !== null && status === 'playing' && <div className="phase-banner"><small>FASE {phaseNotice + 1}</small><strong>{phases[phaseNotice].label}</strong></div>}
    {toast && (status === 'playing' || status === 'question') && <div className="feedback-toast" role="status">{toast}</div>}
    <audio
      ref={musicRef}
      src={`${import.meta.env.BASE_URL}audio/game-music.mp3`}
      loop
      preload="auto"
      onEnded={event => {
        const audio = event.currentTarget;
        audio.currentTime = 0;
        void audio.play().catch(() => setToast('Não foi possível continuar a música neste navegador.'));
      }}
    />
  </main>;
}
